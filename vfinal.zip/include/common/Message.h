#ifndef __MESSAGE_H__
#define __MESSAGE_H__

#define MAX_PAYLOAD_SIZE 500
#define MAX_USERNAME_SIZE 100

// Message types:
#define OK 0
#define NOK 1
#define OPEN_SEND_CONN 2
#define OPEN_RECV_CONN 3
#define OPEN_SESSION 4
#define CREATE_FILE 5
#define FILE_CLOSE_WRITE 6
#define END 7
#define DELETE_FILE 8
#define UPLOAD_FILE_CMD 9
#define DOWNLOAD_FILE_CMD 10 
#define LIST_SERVER_CMD 11


struct Message {
	unsigned int type;
	unsigned int seqn;
	char username[MAX_USERNAME_SIZE];
	char payload[MAX_PAYLOAD_SIZE];
};

Message* Message_create(unsigned int type, unsigned int seqn, const char *username, const char *payload);
void Message_marshall(Message *msg, void *buffer);
void Message_unmarshall(Message *msg, void *buffer);
int Message_send(Message *msg, int sockfd);
int Message_recv(Message *msg, int sockfd);

#endif
