#include <iostream>

using namespace std;

int main (int argc, char **argv)
{

    // cout << "Nothing to do\n";

    // TO-DO

  	return 0;
}
